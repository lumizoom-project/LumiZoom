LUMIZOOM 1.0 RC1 — JEDYNY AKTUALNY INSTALATOR

Uruchom plik:
LumiZoom-1.0-RC1-Setup-STANDARD-v6.exe

Po uruchomieniu zaakceptuj okno UAC, a następnie kliknij Zainstaluj.

Oczekiwany rezultat:
- pliki w C:\Program Files\LumiZoom
- skrót LumiZoom
- wpis LumiZoom w Zainstalowanych aplikacjach
- możliwość odinstalowania

Autor: Łukasz Kuczek
Wersja: 1.0.0 RC1
Kontakt: lumizoom.project@gmail.com

Ten instalator został zbudowany w standardzie Inno Setup i przetestowany:
tworzy Program Files, skrót, wpis systemowy oraz unins000.exe.

Na końcu instalacji można pozostawić zaznaczone automatyczne uruchomienie.

Instalator przed rozpoczęciem sprawdza, czy LumiZoom jest już zainstalowany
oraz czy program nie jest aktualnie uruchomiony.
